import React from 'react';
import pagina_principal from './paginaprincipal.js';

function pagina_principal() {
  return (
    <div>
      
      <paginaprincipal/> {/* Renderiza el componente de inicio de sesión aquí */}
    </div>
    
  );
}

export default pagina_principal;