import React from 'react';
import Signin from './signin.js';

function Signinpage() {
  return (
    <div>
      <Signin /> {}
    </div>
  );
}

export default Signinpage;