// LoginPage.js
import React from 'react';
import Login from './login.js';

function LoginPage() {
  return (
    <div>
      
      <Login /> {/* Renderiza el componente de inicio de sesión aquí */}
    </div>
  );
}

export default LoginPage;