// LoginPage.js
import React from 'react';
import Recuperacion from './Recuperacion.js';

function RecuperacionPage() {
  return (
    <div>
      <Recuperacion/> {/* Renderiza el componente de inicio de sesión aquí */}
    </div>
  );
}

export default RecuperacionPage;